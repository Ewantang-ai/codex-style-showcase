import argparse,json,wave
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--audio',required=True);p.add_argument('--output',required=True);p.add_argument('--model',required=True);p.add_argument('--prompt-file');a=p.parse_args()
import numpy as np
from faster_whisper import WhisperModel
if not Path(a.model).is_dir():raise ValueError('Pass an existing local faster-whisper model directory; no implicit model download')
with wave.open(a.audio) as w:
 if w.getframerate()!=16000 or w.getnchannels()!=1 or w.getsampwidth()!=2:raise ValueError('Expected 16kHz mono PCM16 WAV')
 audio=np.frombuffer(w.readframes(w.getnframes()),np.int16).astype('float32')/32768
prompt=Path(a.prompt_file).read_text(encoding='utf8') if a.prompt_file else None
m=WhisperModel(a.model,device='cpu',compute_type='int8',local_files_only=True)
segments,_=m.transcribe(audio,language='zh',word_timestamps=True,initial_prompt=prompt,vad_filter=False)
rows=[dict(start=s.start,end=s.end,text=s.text,words=[dict(start=w.start,end=w.end,word=w.word) for w in s.words or []]) for s in segments]
Path(a.output).write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8');print('Transcript saved')
