from pathlib import Path
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
import argparse,webbrowser

def main():
    p=argparse.ArgumentParser(description='Play and seek the three native silent examples.')
    p.add_argument('--open',action='store_true')
    p.add_argument('--port',type=int,default=0)
    args=p.parse_args()
    project=Path(__file__).resolve().parents[1]/'assets/project'
    if not (project/'assets/fonts/fonts.css').exists():raise SystemExit('Run scripts/prepare.py first.')
    server=ThreadingHTTPServer(('127.0.0.1',args.port),partial(SimpleHTTPRequestHandler,directory=str(project)))
    url=f'http://127.0.0.1:{server.server_port}/player.html'
    print(url,flush=True)
    if args.open:webbrowser.open(url)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=='__main__':main()
