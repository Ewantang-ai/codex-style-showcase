import sys,shutil
from pathlib import Path
import imageio_ffmpeg
root=Path(sys.argv[1]).resolve();out=root/'tools'/'bin';out.mkdir(parents=True,exist_ok=True)
shutil.copy2(imageio_ffmpeg.get_ffmpeg_exe(),out/('ffmpeg.exe' if sys.platform=='win32' else 'ffmpeg'))
print(out)
