"""Prepare only this Skill's public demo assets and pinned npm dependencies."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,shutil,subprocess,urllib.request,zipfile,os

S=Path(__file__).resolve().parents[1]
P=S/'assets/project'
URL='https://github.com/Ewantang-ai/codex-style-showcase/releases/download/v2.0.0/codex-video-skills-v2.0.0.zip'
EXPECTED='4f6adbfc46c384f207ecc7ed5d8404497f977c8265c434cb3bcd2390d4137656'

def wanted(rel):
    return (rel.startswith('assets/fonts/') or rel.startswith('demos/08-morph/assets/fonts/')
            or rel.startswith('demos/10-synthwave/assets/fonts/')
            or rel in ['assets/textures/paper/Paper001_4K_color.jpg','assets/textures/grain/grain_fine_2048.png'])

def destination(rel):
    if '..' in PurePosixPath(rel).parts:raise ValueError('Invalid archive path')
    target=P.joinpath(*PurePosixPath(rel).parts).resolve()
    target.relative_to(P.resolve())
    target.parent.mkdir(parents=True,exist_ok=True)
    return target

def copy_base(base):
    candidates=[base,base/'skills/mg-style-library/assets',base/'mg-style-library/assets']
    candidates += [p/'skills/mg-style-library/assets' for p in base.iterdir() if p.is_dir()]
    src=next((p for p in candidates if (p/'assets/fonts/fonts.css').is_file()),None)
    if not src:raise SystemExit('Cannot locate the old bundle assets; pass the extracted v2 folder to --base.')
    n=0
    for f in src.rglob('*'):
        if f.is_file() and wanted(f.relative_to(src).as_posix()):
            shutil.copy2(f,destination(f.relative_to(src).as_posix()));n+=1
    return n

def copy_zip(bundle):
    h=hashlib.sha256()
    with bundle.open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
    if h.hexdigest()!=EXPECTED:raise SystemExit('ZIP SHA256 does not match the verified v2.0.0 bundle. Please download it again.')
    n=0
    with zipfile.ZipFile(bundle) as z:
        for info in z.infolist():
            marker='skills/mg-style-library/assets/'
            if marker not in info.filename or info.is_dir():continue
            rel=info.filename.split(marker,1)[1]
            if wanted(rel):
                with z.open(info) as a,destination(rel).open('wb') as b:shutil.copyfileobj(a,b)
                n+=1
    return n

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base',type=Path,help='Previously extracted v2 bundle (no download)')
    p.add_argument('--bundle',type=Path,help='Already downloaded verified v2.0.0 ZIP')
    p.add_argument('--skip-npm',action='store_true',help='Only prepare fonts and textures')
    args=p.parse_args()
    if args.base:n=copy_base(args.base.expanduser().resolve())
    else:
        bundle=args.bundle
        if bundle is None:
            cache=S/'download-cache';cache.mkdir(exist_ok=True)
            bundle=cache/'codex-video-skills-v2.0.0.zip'
            if not bundle.exists():
                part=bundle.with_suffix('.part')
                print('Downloading the public v2 asset bundle (about 218 MiB)...',flush=True)
                try:
                    with urllib.request.urlopen(URL,timeout=60) as response,part.open('wb') as out:
                        shutil.copyfileobj(response,out,1024*1024)
                    part.replace(bundle)
                except Exception as exc:
                    raise SystemExit(f'Download failed: {exc}\nDownload the v2 ZIP manually, then use --bundle with its file path.')
        n=copy_zip(bundle.expanduser().resolve())
    required=['assets/fonts/fonts.css','assets/textures/paper/Paper001_4K_color.jpg','assets/textures/grain/grain_fine_2048.png','demos/08-morph/assets/fonts/Outfit-SemiBold.ttf','demos/10-synthwave/assets/fonts/MrDafoe-Regular.ttf']
    for rel in required:
        if not (P/rel).is_file() or (P/rel).stat().st_size<10:raise SystemExit('Missing or invalid asset: '+rel)
    print(f'Prepared {n} public font/texture files.',flush=True)
    if not args.skip_npm:
        npm=shutil.which('npm.cmd' if os.name=='nt' else 'npm')
        if not npm:raise SystemExit('Node.js/npm was not found. Install Node.js, then run this preparation again.')
        subprocess.run([npm,'install','--no-audit','--no-fund'],cwd=P,check=True)
    print('Ready. Run: python scripts/preview.py --open',flush=True)

if __name__=='__main__':main()
