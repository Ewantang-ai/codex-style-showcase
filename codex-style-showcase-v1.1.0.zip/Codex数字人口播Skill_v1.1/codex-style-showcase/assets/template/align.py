"""Align the actual script to ASR words; anchors are configurable, not fixed times."""
import argparse, difflib, json, math, re, wave
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--project',default=str(Path(__file__).resolve().parent))
p.add_argument('--trim',type=float)
p.add_argument('--min-match',type=float,default=.65)
a=p.parse_args(); R=Path(a.project).resolve()
def valid(c): return '\u4e00'<=c<='\u9fff' or c.isascii() and c.isalnum()
def norm(s): return ''.join(c.lower() for c in s if valid(c))
script=(R/'口播文案.txt').read_text(encoding='utf-8').strip()
original=norm(script)
raw=json.loads((R/'transcript.json').read_text(encoding='utf-8'))
chars=[]; times=[]
for seg in raw:
    for word in seg.get('words',[]):
        letters=norm(word['word']); start=float(word['start']); end=float(word['end'])
        if not letters or end<=start: continue
        if times and start<times[-1]-.02: raise ValueError('ASR word times must be chronological.')
        for i,c in enumerate(letters): chars.append(c); times.append(start+(end-start)*i/len(letters))
if not original or not times: raise ValueError('Need nonempty script and actual ASR word timestamps.')
mapping={}
for block in difflib.SequenceMatcher(None,original,''.join(chars),autojunk=False).get_matching_blocks():
    for j in range(block.size): mapping[block.a+j]=times[block.b+j]
match=len(mapping)/len(original)
if match<a.min_match: raise ValueError(f'Script/ASR match {match:.1%}; fix transcript or actual script before aligning.')
ids=sorted(mapping); aligned=np.interp(np.arange(len(original)),ids,[mapping[i] for i in ids])
with wave.open(str(R/'assets'/'voice.wav')) as wav: source_duration=wav.getnframes()/wav.getframerate()
trim=round(max(0,times[0]-.2)*25)/25 if a.trim is None else a.trim
if not 0<=trim<source_duration: raise ValueError('Trim outside source audio.')
duration=math.floor((source_duration-trim)*25+1e-6)/25
spec=json.loads((R/'anchors.json').read_text(encoding='utf-8')); anchors={}
for key,value in spec.items():
    phrase=norm(value if isinstance(value,str) else value['phrase'])
    occurrence=1 if isinstance(value,str) else int(value.get('occurrence',1))
    if not phrase or occurrence<1: raise ValueError(f'Invalid anchor: {key}')
    found=-1
    for _ in range(occurrence):
        found=original.find(phrase,found+1)
        if found<0: break
    if found<0: raise ValueError(f'Missing anchor {key}: {value}. Update anchors.json for the new script.')
    anchors[key]=round(max(0,float(aligned[found])-trim),4)
captions=[]; cursor=0
for clause in re.split(r'[，。？！？；：、\n]+',script):
    clause=clause.strip()
    if not norm(clause): continue
    tokens=re.findall(r'[A-Za-z0-9]+|.',clause)
    groups=[]; group=''
    for token in tokens:
        if len(norm(group+token))>16 and group: groups.append(group); group=''
        group+=token
    if group: groups.append(group)
    for text in groups:
        n=len(norm(text)); source_times=[float(x) for x in aligned[cursor:cursor+n]]
        start=max(0,source_times[0]-trim); end=min(duration,source_times[-1]+.17-trim)
        captions.append(dict(start=round(start,4),end=round(end,4),text=text,chars=source_times)); cursor+=n
for i in range(len(captions)-1): captions[i]['end']=min(captions[i]['end'],captions[i+1]['start']-.001)
def stamp(t):
    ms=round(max(0,t)*1000); return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d}.{ms%1000:03d}'
vtt=['WEBVTT','']
for i,c in enumerate(captions):
    if c['end']<=c['start']: raise ValueError('Collapsed subtitle times; check ASR words, punctuation and pauses.')
    text=''; j=0
    for token in re.findall(r'[A-Za-z0-9]+|.',c['text']):
        n=len(norm(token))
        if n:
            tag=min(c['end']+trim-.001,max(c['start']+trim,c['chars'][j]))
            text+=f'<{stamp(tag)}>{token}'; j+=n
        else: text+=token
    vtt.extend([str(i+1),f'{stamp(c["start"]+trim)} --> {stamp(c["end"]+trim)}',text,''])
(R/'assets'/'voice.vtt').write_text('\n'.join(vtt),encoding='utf-8')
out=dict(trim=trim,duration=duration,sourceDuration=source_duration,anchors=anchors,captions=captions,match=round(match,4),demo=(R/'DEMO_ONLY.txt').exists())
(R/'timing.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(duration=duration,trim=trim,match=round(match,4),anchors=len(anchors),captions=len(captions),demo=out['demo']),ensure_ascii=False))
