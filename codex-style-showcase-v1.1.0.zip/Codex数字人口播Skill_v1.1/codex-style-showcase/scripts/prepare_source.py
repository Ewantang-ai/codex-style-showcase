"""Extract real speech and green/alpha presenter frames, preserving the source bottom."""
import argparse, json, math, shutil, subprocess, sys, wave
from pathlib import Path
import av, numpy as np
from PIL import Image
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--input',required=True); p.add_argument('--project',required=True)
p.add_argument('--crop',help='x,y,width,height; must preserve original bottom')
p.add_argument('--mode',choices=['green','alpha'],default='green')
a=p.parse_args(); source=Path(a.input).resolve(); R=Path(a.project).resolve()
person=R/'assets'/'person'
if person.exists() and any(person.iterdir()): raise SystemExit('Person frames already exist; use a new project or move the old source aside first.')
if (R/'assets'/'voice.wav').exists(): raise SystemExit('voice.wav already exists; preserve it and use a new project.')
ffmpeg=R/'tools'/'bin'/('ffmpeg.exe' if sys.platform=='win32' else 'ffmpeg')
if not ffmpeg.exists():
    found=shutil.which('ffmpeg')
    if not found: raise SystemExit('FFmpeg missing. Run setup_ffmpeg.py PROJECT first.')
    ffmpeg=Path(found)
with av.open(str(source)) as c:
    if not c.streams.video or not c.streams.audio: raise ValueError('Input must include actual video and speech audio.')
    s=c.streams.video[0]; fps=float(s.average_rate)
    crop=[int(v) for v in a.crop.split(',')] if a.crop else [0,0,s.width,s.height]
    if len(crop)!=4: raise ValueError('Crop requires x,y,w,h.')
    x,y,w,h=crop
    if min(x,y)<0 or min(w,h)<=0 or x+w>s.width or y+h!=s.height: raise ValueError('Crop out of bounds or does not preserve the source bottom.')
    person.mkdir(parents=True,exist_ok=True); first_pts=None; count=0
    for i,f in enumerate(c.decode(s)):
        if f.time is not None:
            if first_pts is None: first_pts=float(f.time)
            if abs(float(f.time)-first_pts-i/fps)>1/fps:
                raise ValueError('Variable-rate source detected; normalize to constant frame rate first, preserving audio sync.')
        rgba=f.to_ndarray(format='rgba')[y:y+h,x:x+w].astype('float32'); rgb=rgba[...,:3]
        if a.mode=='alpha': alpha=rgba[...,3:4]/255
        else:
            g=rgb[...,1]; neutral=np.maximum(rgb[...,0],rgb[...,2]); ex=g-neutral
            key=np.clip((ex-10)/65,0,1); key=key*key*(3-2*key); alpha=(1-key)[...,None]
            rgb[...,1]=g-np.maximum(ex,0)*np.clip((ex-5)/25,0,1)
        q=np.concatenate([rgb*alpha,alpha],axis=2)
        pad=np.pad(q,((0,0),(1,1),(0,0)),mode='edge'); q=.08*pad[:,:-2]+.84*pad[:,1:-1]+.08*pad[:,2:]
        pad=np.pad(q,((1,1),(0,0),(0,0)),mode='edge'); q=.08*pad[:-2]+.84*pad[1:-1]+.08*pad[2:]
        alpha=q[...,3:4]; rgb=np.divide(q[...,:3],alpha,out=np.zeros_like(q[...,:3]),where=alpha>.005)
        frame=np.concatenate([rgb,alpha*255],axis=2).clip(0,255).astype('uint8')
        Image.fromarray(frame).save(person/f'{i:04d}.webp',quality=98,alpha_quality=100,method=2,exact=True)
        count+=1
        if i%100==0: print(f'frames={i}',flush=True)
    if not count: raise ValueError('No video frames decoded.')
(R/'person.json').write_text(json.dumps(dict(width=w,height=h,fps=fps,frames=count,duration=count/fps,crop=crop,mode=a.mode)),encoding='utf-8')
voice=R/'assets'/'voice.wav'
if voice.exists(): raise SystemExit('voice.wav already exists; preserve it and choose a new project for new speech.')
subprocess.run([str(ffmpeg),'-v','error','-n','-i',str(source),'-vn','-ac','1','-ar','16000','-c:a','pcm_s16le',str(voice)],check=True)
with wave.open(str(voice)) as v: rate=v.getframerate(); z=np.frombuffer(v.readframes(v.getnframes()),np.int16).astype(float)/32768
step=round(rate*.025)
(R/'waveform.json').write_text(json.dumps([float(np.sqrt(np.mean(z[j:j+step]**2))) for j in range(0,len(z),step)]),encoding='utf-8')
print(json.dumps(dict(project=str(R),frames=count,fps=fps,size=[w,h],audioSeconds=len(z)/rate)))
