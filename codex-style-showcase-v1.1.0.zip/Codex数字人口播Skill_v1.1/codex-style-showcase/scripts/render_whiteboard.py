"""Invoke the installed srt-whiteboard-animation renderer, with source-matched paper and pen tip."""
import sys,json,os
from pathlib import Path
from dataclasses import replace
import numpy as np
R=Path(sys.argv[1]).resolve();P=R/'assets'/'whiteboard'
os.environ['PATH']=str(R/'tools'/'bin')+os.pathsep+os.environ.get('PATH','')
skill=Path(__file__).parent/'whiteboard'
sys.path.insert(0,str(skill))
import stream_render as sr
from render_stream_whiteboard import RegionStreamRenderer
img=sr._imread_any(P/'scene-handdraw.png');h,w=img.shape[:2]
samples=[img[10:25,10:25],img[10:25,w-25:w-10],img[h-25:h-10,10:25],img[h-25:h-10,w-25:w-10]]
b,g,r=np.median(np.concatenate([s.reshape(-1,3) for s in samples]),axis=0).astype(int)
cfg=sr.Config(fps=25,cap_long_edge=1920,grid_edge=6,ink_path_mode='skeleton',color_fill='brush',target_hand_height=800,canvas_hex=f'#{r:02x}{g:02x}{b:02x}',tip_anchor_x=.055,tip_anchor_y=.0625)
ann=json.loads((P/'scene-handdraw.annotation.json').read_text(encoding='utf8'))
rr=RegionStreamRenderer(img,ann,cfg,P/'drawing-hand.png',False)
print(f'Official Skill renderer; {rr.out_w}x{rr.out_h}; canvas={cfg.canvas_hex}; skeleton ink + brush color',flush=True)
raw=rr.render_to(P/'scene-handdraw_raw.mp4',ann['sceneDurationMs'])
final=sr.transcode_h264(raw,P/'scene-handdraw-whiteboard.mp4')
print('OUTPUT='+str(final),flush=True)

