let copyMap={},projectConfig={presenterName:'我的数字人'};
const copyText=s=>copyMap[s]??s;
const W=1280,H=720,clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),ease=x=>1-Math.pow(1-clamp(x),3);
const tw=(t,a,b,x=0,y=1)=>x+(y-x)*ease((t-a)/(b-a));
const pop=(t,a,s=.6)=>{let u=clamp((t-a)/s);return u===0?0:1+Math.exp(-6*u)*Math.sin(u*11)*.32;};
const style=o=>Object.entries(o).map(([k,v])=>`${k.replace(/[A-Z]/g,c=>'-'+c.toLowerCase())}:${v}`).join(';');
const box=(x,y,w,h,html='',extra={},cls='')=>`<div class="abs ${cls}" style="${style({left:x+'px',top:y+'px',...(w==null?{}:{width:w+'px'}),...(h==null?{}:{height:h+'px'}),...extra})}">${html}</div>`;
let textEntryTime=0,textEntryIndex=0;
const txt=(s,x,y,z=50,e={})=>{s=copyText(s);const at=Math.min(.18,textEntryIndex++*.035),p=tw(textEntryTime,at,at+.46);return box(x,y,null,null,`<span style="display:inline-block;vertical-align:top;opacity:${p};clip-path:inset(0 ${(1-p)*100}% 0 0);transform:translateY(${(1-p)*11}px)">${s}</span>`,{fontSize:z+'px',fontWeight:850,lineHeight:1.18,whiteSpace:'nowrap',...e});};
function wordIn(s,t,at){return [...copyText(s)].map((c,i)=>{let p=tw(t,at+i*.035,at+i*.035+.3);return `<span style="display:inline-block;opacity:${p};transform:translateY(${(1-p)*9}px);clip-path:inset(${(1-p)*100}% 0 0 0)">${c===' '?'&nbsp;':c}</span>`}).join('');}
let data,meta,introData=null,waveform=[];const A=k=>data.anchors[k];
const actorURL=t=>`assets/person/${String(clamp(Math.floor((t+data.trim)*meta.fps),0,meta.frames-1)).padStart(4,'0')}.webp`;
// Invariant: lower cut edge is exactly stage bottom in every main shot.
function actor(t,x,w,extra={},source='main'){
 const useIntro=source==='intro'&&introData,m=useIntro?introData.person:meta,h=w*m.height/m.width;
 const src=useIntro?`${introData.baseURL}/${String(clamp(Math.floor((t+introData.trim)*m.fps),0,m.frames-1)).padStart(4,'0')}.webp`:actorURL(t);
 return `<img class="person" data-bottom="720" alt="我的数字人" src="${src}" style="${style({left:x+'px',top:(H-h)+'px',width:w+'px',height:h+'px',...extra})}">`;
}
function svg(inner,w=400,h=250){return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" overflow="visible">${inner}</svg>`;}
function path(d,p=1,c='#263434',width=4){return `<path d="${d}" fill="none" stroke="${c}" stroke-width="${width}" stroke-linecap="round" stroke-linejoin="round" pathLength="1" stroke-dasharray="1" stroke-dashoffset="${1-clamp(p)}"/>`;}
function star(n=12,r=65,r2=49){let d='';for(let i=0;i<n*2;i++){let a=i*Math.PI/n-Math.PI/2,rr=i%2?r2:r;d+=(i?'L':'M')+(75+Math.cos(a)*rr)+','+(75+Math.sin(a)*rr)}return d+'Z';}
function brand(s,color='#e9e9fa'){return txt(s,44,35,12,{fontWeight:600,color,letterSpacing:'2px'})+txt(projectConfig.presenterName+' · AI数字人',1086,35,11,{fontWeight:500,color,letterSpacing:'1px'});}
function paperBase(mustard=false){return `<div class="fill ${mustard?'mustard':'paper'}"></div><div class="grain"></div>`;}
function techBase(t){return `<div class="fill photo" style="transform:scale(1.018)"></div><div class="fill" style="background:linear-gradient(90deg,#17150f70,transparent 44%),linear-gradient(180deg,#211a142b,transparent 58%,#16120e26)"></div>`;}
function wave(t,n=38,h=40,col='#bcb2ff'){let base=Math.floor((t+data.trim)/.025);return `<div class="wave" style="height:${h}px">${Array.from({length:n},(_,i)=>{let a=waveform[clamp(base+(i-n/2)*2,0,waveform.length-1)]||0;return `<i style="height:${Math.min(h,3+a*h*6)}px;background:${col}"></i>`}).join('')}</div>`;}
function icon(k=0,color='#f7f3ff',size=48){const d=[`<path d="M10 8h24l7 7v25H10Z"/><path d="M34 8v9h7M17 24h16M17 31h12"/>`,`<rect x="5" y="10" width="38" height="28" rx="7"/><path d="m21 18 11 6-11 6Z"/>`,`<path d="M7 25c7-21 11 20 18-4s13 13 17-4M7 38h35"/>`,`<path d="m15 12-10 12 10 12M33 12l10 12-10 12M29 7 20 41"/>`,`<path d="M6 15h15l5 5h16v22H6ZM6 15V8h17l5 7"/>`];return `<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" stroke="${color}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">${d[k%5]}</svg>`;}
function prop(k,x,y,w,t,at,rot=0){let p=tw(t,at,at+.58);return box(x,y,w,w,'',{zIndex:10,opacity:p,transform:`translateY(${(1-p)*34}px) rotate(${rot-(1-p)*9}deg) scale(${.96+.04*p})`,transformOrigin:'20% 80%',backgroundImage:"url('assets/paper-props-v2.png')",backgroundSize:'200% 200%',backgroundPosition:k===2?'0% 100%':'100% 100%',filter:`drop-shadow(${4+3*(1-p)}px ${5+8*(1-p)}px 5px #1b342630)` });}
function paperTag(s,x,y,z,t,at,rot=0){const p=tw(t,at,at+.48);return box(x,y,null,null,wordIn(s,t,at+.07),{zIndex:15,fontSize:z+'px',fontWeight:900,padding:'8px 22px',opacity:p,transform:`perspective(700px) translateY(${(1-p)*22}px) rotateX(${(1-p)*-26}deg) rotate(${rot+(1-p)*5}deg)`,transformOrigin:'left bottom'},'tag');}
function stickerGuide(t){
 const u=clamp((t-A('arrow'))/(A('focus')-A('arrow'))),p=u*u*(3-2*u),x=18*(1-p)*(1-p)+2*111*p*(1-p)+224*p*p,y=130*(1-p)*(1-p)+2*133*p*(1-p)+70*p*p;
 const dx=2*(1-p)*(111-18)+2*p*(224-111),dy=2*(1-p)*(133-130)+2*p*(70-133),angle=Math.atan2(dy,dx)*180/Math.PI;
 const head=tw(t,A('focus')-.16,A('focus')+.08),ring=clamp((t-A('focus'))/.7);
 const line=path('M18 130Q111 133 224 70',p,'#d16b43',4.2)+path('M18 133Q112 136 225 73',p,'#e7a36b',1.2);
 const marker=`<g transform="translate(${x},${y}) rotate(${angle})"><circle r="${3.3*(1-head)}" fill="#cc6843"/><path d="M-11-7 0 0-11 7" fill="none" stroke="#ca653e" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round" opacity="${head}"/></g>`;
 return box(710,350,300,180,svg(`<g opacity="${tw(t,A('arrow'),A('arrow')+.1)}">${line}${marker}<circle cx="224" cy="70" r="${10+ring*38}" fill="none" stroke="#d16b43" stroke-width="2" opacity="${t>A('focus')?(1-ring)*.65:0}"/></g>`,300,180),{zIndex:12});
}

function codexOpening(t){
 const letters=['C','o','d','e','x'],xs=[8,150,283,414,544],widths=[128,116,120,115,116];
 let defs='',lettersHTML='';
 for(let i=0;i<letters.length;i++){
  const p=tw(t,.12+i*.075,.67+i*.075),y=14*(1-p);
  defs+=`<clipPath id="codex-reveal-${i}"><rect x="-16" y="-40" width="${(widths[i]+36)*p}" height="330"/></clipPath>`;
  lettersHTML+=`<g transform="translate(${xs[i]},0)" opacity="${p}"><g ${p<.999?`clip-path="url(#codex-reveal-${i})"`:''}><text x="0" y="${202+y}" font-family="SC" font-size="190" font-weight="650" fill="#faf7ed" textLength="${widths[i]}" lengthAdjust="spacingAndGlyphs">${letters[i]}</text></g></g>`;
 }
 const line=tw(t,.48,1.28),at=introData?.anchors.codex||1.2,accent=tw(t,at-.12,at+.48)*(1-tw(t,at+.9,at+1.35));
 const cursor=(t>.65&&t<1.5)?(1-tw(t,1.14,1.5))*.65:0;
 return box(480,93,710,255,`<svg width="710" height="255" viewBox="0 0 710 255" overflow="visible" role="img" aria-label="Codex 动态字标"><defs>${defs}</defs>${lettersHTML}<path d="M10 229H${10+650*line}" fill="none" stroke="#f1ebdd" stroke-opacity=".32" stroke-width="1.2"/><path d="M10 229H${10+650*tw(t,at-.12,at+.48)}" fill="none" stroke="#e1b777" stroke-opacity="${accent}" stroke-width="2.4"/><rect x="678" y="69" width="3" height="135" rx="1.5" fill="#efe9dc" opacity="${cursor}"/></svg>`,{zIndex:11,filter:'drop-shadow(0 3px 10px #21170f88)'});
}

function intro(t){
 let html=techBase(t)+brand('CODEX / 四种动画风格');
 html+=txt(introData?'从文案到成片':'一条口播',52,117,introData?38:47,{fontWeight:600,letterSpacing:'-2px',opacity:tw(t,0,.4)});
 html+=txt(introData?'全程让它做':'四种玩法。',49,179,introData?55:64,{color:'#ddd5ff',letterSpacing:'-3px',transform:`translateY(${tw(t,.25,.8,22,0)}px)`,opacity:tw(t,.25,.75)});
 html+=codexOpening(t);
 html+=actor(t,360,650,{filter:'drop-shadow(0 3px 20px #0003)'},'intro');
 const specs=introData?[['文案','SCRIPT','#f4c14b',47,379,-8,introData.anchors.script],['口播','VOICE','#faf6e9',156,527,6,introData.anchors.voice],['动画','MOTION','#171a31',990,365,7,introData.anchors.motion],['剪辑','EDIT','#bafb4e',1012,532,-8,introData.anchors.edit]]:[['贴纸','STICKER','#f4c14b',47,379,-8],['手绘','DRAW','#faf6e9',156,527,6],['科技','INTERFACE','#171a31',990,365,7],['动字','TYPE','#bafb4e',1012,532,-8]];
 for(let i=0;i<specs.length;i++){let [s,en,c,x,y,r,at]=specs[i];at=at??(.65+i*.7);const p=tw(t,at,at+.5);html+=box(x,y,205,130,`<div class="tiny" style="opacity:${tw(t,at+.1,at+.4)}">${en} / 0${i+1}</div><div style="font-size:49px;font-weight:900;margin-top:10px">${wordIn(s,t,at+.08)}</div>`,{padding:'18px 23px',background:c,color:i===2?'#dcd7ff':'#15342c',borderRadius:i===2?'20px':'2px',boxShadow:'4px 8px 17px #0003',zIndex:30,opacity:p,transform:`perspective(800px) translateY(${(1-p)*23}px) rotateX(${(1-p)*-19}deg) rotate(${r+(1-p)*4}deg) scale(${.98+.02*p})`,transformOrigin:'left bottom'});}
 if(introData)html+=txt('直接看效果 →',68,288,23,{color:'#dad3ed',fontWeight:550,opacity:tw(t,introData.anchors.view,introData.anchors.view+.3)});
 return html;
}
function sticker(t){
 let html=paperBase(true)+brand('01 / 贴纸动画','#173832');
 html+=box(-100,540,800,300,'',{background:'#153e34',clipPath:'polygon(0 13%,8% 4%,15% 9%,23% 0,31% 10%,40% 5%,49% 14%,60% 6%,71% 12%,82% 3%,92% 8%,100% 0,100% 100%,0 100%)',transform:'rotate(11deg)'});
 html+=box(930,-70,420,290,'',{backgroundImage:"url('assets/paper-cream.jpg')",backgroundSize:'cover',transform:'rotate(17deg)',boxShadow:'0 12px 12px #4c361b33'});
 html+=txt('贴上去，就活了。',55,116,65,{color:'#173832',letterSpacing:'-3px',zIndex:22});
 html+=actor(t,-70,705,{filter:'drop-shadow(4px 0 #fff9e2) drop-shadow(-4px 0 #fff9e2) drop-shadow(0 -4px #fff9e2) drop-shadow(7px 8px #17383255)'});
 const p=tw(t,A('stickers'),A('stickers')+.55);
 html+=box(618,206,501,348,`<div style="font-size:21px;font-weight:750;color:#63705b;padding:25px">${wordIn('我的动画手账',t,A('stickers')+.12)}</div><div style="position:absolute;left:36px;right:36px;top:87px;height:1px;background:#b6b59e"></div><div style="position:absolute;left:36px;right:36px;top:137px;height:1px;background:#b6b59e"></div><div style="position:absolute;left:36px;right:36px;top:187px;height:1px;background:#b6b59e"></div>`,{opacity:p,transform:`perspective(900px) translateY(${(1-p)*30}px) rotateY(${(1-p)*-10+tw(t,A('notebook'),A('notebook')+.6,0,-8)}deg) rotate(-4deg) scale(${.97+.03*p})`,zIndex:3},'paper-card');
 html+=box(674,181,183,32,'',{opacity:tw(t,A('stickers')+.2,A('stickers')+.6),transform:`translateY(${(1-p)*10}px) rotate(-9deg)`,zIndex:8},'tape');
 html+=prop(2,946,345,225,t,A('stickers')+.35,7);
 html+=prop(3,602,400,202,t,A('stack')+.3,-8);
 html+=paperTag('纸片',815,279,43,t,A('stickers')+.05,-6);
 html+=paperTag('小道具',895,477,38,t,A('stickers')+.65,7);
 html+=paperTag('一层一层',628,330,36,t,A('stack'),-8);
 html+=stickerGuide(t);
 let jump=t<A('focus')?0:Math.sin(clamp((t-A('focus'))/.52)*Math.PI)*-12;
 const focus=tw(t,A('focus'),A('focus')+.35);
 html+=box(866,350+jump,150,150,svg(`<path d="${star()}" fill="#d97447" stroke="#fff1d6" stroke-width="5"/><text x="75" y="83" text-anchor="middle" fill="#fff5dc" font-size="34" class="svgtext" opacity="${tw(t,A('focus')+.08,A('focus')+.3)}">重点</text>`,150,150),{zIndex:13,opacity:focus,transform:`rotate(6deg) scale(${.93+.07*focus})`});
 html+=paperTag('会动的手账 ↗',721,574,27,t,A('notebook'),-3);
 return html;
}
function drawing(t){
 // Artwork and the continuous drawing are rendered by srt-whiteboard-animation.
 // This transparent OpenFilm layer only keeps the presenter, title and brand editable.
 let html=brand('02 / 手绘讲解','#53605a');
 html+=txt('边说，边画。',55,119,76,{color:'#243332',letterSpacing:'-3px'});
 html+=txt('让想法，一笔一笔成形',59,211,20,{color:'#798075',fontWeight:500,letterSpacing:'3px'});
 html+=actor(t,823,540,{filter:'drop-shadow(7px 0 #d8d4bb)'});
 return html;
}

function miniCard(i,t,w=230){
 const cols=['#c6b8ff','#9be0d0','#f4bf81','#eef0ff','#c5ff7e','#ff9fae'];let c=cols[i%6],inside='';
 if(i%6===0)inside=`<div class="tiny" style="color:${c}">口播音轨</div><div style="margin-top:20px">${wave(t,31,48,c)}</div>`;
 if(i%6===1)inside=`<div class="tiny" style="color:${c}">MOTION / 缓动</div>${svg(path('M4 85C62 84 62 8 165 8',1,c,3),180,100)}`;
 if(i%6===2)inside=`<div class="tiny" style="color:${c}">STICKER / 01</div><div style="display:flex;gap:10px;margin-top:19px">${['纸','片','动'].map((s,j)=>`<b style="font-size:31px;transform:rotate(${[-8,5,-3][j]}deg);background:${c};color:#29362c;padding:5px">${s}</b>`).join('')}</div>`;
 if(i%6===3)inside=`<div class="tiny" style="color:${c}">画面编排</div><div style="display:flex;gap:7px;margin-top:16px">${[0,1,2].map((_,j)=>`<div style="height:${55+j*9}px;width:49px;background:${['#6c6598','#9883c1','#d8cffa'][j]};border-radius:6px;transform:translateY(${Math.sin(t+j)*6}px)"></div>`).join('')}</div>`;
 if(i%6===4)inside=`<div class="tiny" style="color:${c}">KINETIC TYPE</div><div style="font-size:43px;font-weight:950;margin-top:18px;color:${c};transform:skewX(${Math.sin(t)*-7}deg)">动起来</div>`;
 if(i%6===5)inside=`<div class="tiny" style="color:${c}">进度 / 节奏</div><div style="font-size:43px;font-weight:850;margin-top:11px">${Math.floor((t%3)/3*100)}<small style="font-size:17px">%</small></div><div class="mini-bar"><div style="width:${t%3/3*100}%;height:100%;background:${c}"></div></div>`;
 return box(0,0,230,160,inside,{padding:'20px',transform:`scale(${w/230})`,transformOrigin:'top left'},'glass');
}
function interfacePanel(t,p){
 let html=box(0,0,690,359,`<div class="chrome"><i></i><i></i><i></i><b>CODEX / MOTION STUDIO</b></div><div style="padding:15px 24px;font-size:29px;font-weight:800">让画面，跟上声音。</div>`,{background:'#131626f2'},'glass');
 html+=box(22,110,300,151,`<div style="font-size:49px;font-weight:900;color:#d4c5ff;line-height:1.15">一条口播<br>四种玩法</div>`);
 for(let i=0;i<3;i++)html+=box(338+i*105,112,98,120,icon(i,'#d3c7ff',37)+`<div style="font-size:12px;margin-top:15px">${['声音','动画','成片'][i]}</div>`,{padding:'15px 13px',background:['#27283f','#252e3d','#3d3142'][i],borderRadius:'12px',transform:`translateY(${(1-p)*(i+1)*25}px)`,opacity:p});
 html+=box(23,282,643,53,`<div style="display:flex;gap:13px;align-items:center"><span style="font-size:11px;letter-spacing:2px">VOICE</span><div style="flex:1">${wave(t,62,30)}</div><span style="font-size:11px">▸</span></div>` ,{borderTop:'1px solid #b2b5de33',paddingTop:'12px'});
 return html;
}
function tech(t){
 let html=techBase(t)+brand('03 / 科技交互');
 html+=txt('画面，有了纵深。',50,113,67,{letterSpacing:'-3px',opacity:1-tw(t,A('capsule'),A('capsule')+.5)});
 const morph=tw(t,A('capsule'),A('capsule')+.6),ax=tw(t,A('capsule'),A('capsule')+.8,344,838),aw=tw(t,A('capsule'),A('capsule')+.8,650,530);
 let cards=[];
 for(let i=0;i<9;i++){let a=(t-A('orbit'))*.64+i*2*Math.PI/9;let depth=Math.sin(a),scale=.69+depth*.21,ww=230*scale;let x=640+Math.cos(a)*440-ww/2,y=400+depth*230-80*scale;
  cards.push({z:depth>0?31:8,s:box(x,y,ww,160*scale,miniCard(i,t,ww),{zIndex:depth>0?31:8,filter:depth<-.45?'blur(.5px)':'none',opacity:tw(t,A('tech')+.2+i*.12,A('tech')+.55+i*.12)*(1-morph),transform:`perspective(900px) rotateY(${-Math.cos(a)*22}deg) rotateZ(${Math.cos(a)*5}deg)`})});}
 html+=cards.filter(x=>x.z<20).map(x=>x.s).join('');
 html+=actor(t,ax,aw,{filter:'drop-shadow(0 10px 20px #03030c55)'});
 html+=cards.filter(x=>x.z>20).map(x=>x.s).join('');
 const isPlayer=tw(t,A('player'),A('player')+.35),isProgress=tw(t,A('progress'),A('progress')+.35),expand=tw(t,A('expand'),A('expand')+.65);
 let x=66,y=tw(t,A('expand'),A('expand')+.65,232,232),ww=250+isPlayer*315+expand*125,hh=82+isPlayer*54+expand*223;
 html+=box(x,y,ww,hh,`<div style="opacity:${1-expand};padding:19px 22px;display:flex;align-items:center;gap:18px"><div style="width:45px;height:45px;background:#8c79c9;border-radius:13px;display:grid;place-items:center">${icon(isProgress>.5?0:1,'#fff',27)}</div><div style="width:${isPlayer>0?160:130}px;white-space:nowrap"><b style="font-size:22px">${isProgress>.5?'合成进度':'我的播放器'}</b><div class="tiny" style="margin-top:7px;color:#a09bb7">VOICE → MOTION</div></div><div style="width:210px;opacity:${isPlayer*(1-isProgress)}">${wave(t,30,46)}</div></div>${box(21,92,Math.max(100,ww-42),8,`<div style="height:8px;background:linear-gradient(90deg,#8d85e9,#d4ccff);width:${tw(t,A('progress'),A('expand')+.3,4,100)}%;border-radius:5px"></div>`,{opacity:isProgress*(1-expand),background:'#4c456c',borderRadius:'5px'})}${box(0,0,690,359,interfacePanel(t,expand),{opacity:expand})}`,{zIndex:40,opacity:morph,background:'#131425ef',border:'1px solid #c7bef960',borderRadius:(43-expand*24)+'px',boxShadow:'0 28px 70px #0006',overflow:'hidden'});
 html+=txt('胶囊 → 播放器 → 进度 → 动态界面',70,tw(t,A('expand'),A('expand')+.7,402,626),18,{fontWeight:500,letterSpacing:'1px',color:'#c6bce2',opacity:morph});
 return html;
}
function typography(t){
 const split=tw(t,A('split'),A('split')+.55),shuffle=tw(t,A('offset'),A('offset')+.48),crossIn=tw(t,A('cross'),A('cross')+.12),join=tw(t,A('combine'),A('combine')+1.15);
 let html=`<div class="fill" style="background:#c0f45c"></div><div class="grain"></div>`+brand('04 / 动态大字','#18382d');
 html+=txt('让字，也有动作。',52,109,40,{color:'#1d3b2e',fontWeight:600,letterSpacing:'-1px'});
 html+=txt('MOTION',40,510,160,{color:'#1d3b2e12',fontWeight:950,letterSpacing:'-7px'});
 const chars=['让','字','动','起','来'],order=[2,0,4,1,3];
 chars.forEach((s,i)=>{
  const spread=split*(1-shuffle)*(1-join),slot=i+(order[i]-i)*shuffle*(1-join);
  const spin=clamp((t-A('rotate')-i*.045)/.95),angle=360*(spin*spin*(3-2*spin));
  const xx=64+slot*126+spread*[20,-13,37,-4,26][i];
  const interweave=130*Math.sin((t-A('cross'))*Math.PI*2/.72+i*Math.PI)*crossIn*(1-join);
  const yy=285+spread*[80,-65,20,110,-30][i]+interweave;
  const scale=pop(t,A('type')+.05+i*.12);
  html+=txt(s,xx,yy,125,{color:i===2?'#f8f7e8':'#14352b',fontWeight:950,zIndex:interweave<0?28:8,transform:`rotate(${angle}deg) scale(${scale})`,transformOrigin:'50% 50%',textShadow:i===2?'6px 8px 0 #15352d':'none'});
 });
 html+=actor(t,798,580,{filter:'drop-shadow(9px 7px #173b3044)'});
 const cues=[['拆开',A('split')],['旋转 360°',A('rotate')],['重新排序',A('offset')],['上下穿插',A('cross')]];
 const active=t>=A('cross')?3:t>=A('offset')?2:t>=A('rotate')?1:0;
 cues.forEach(([label,at],i)=>{const on=i===active;html+=txt(label,66+i*170,610,25,{color:on?'#102f25':'#53783c',fontWeight:on?900:550,opacity:tw(t,at,at+.16)*(1-join),borderBottom:on?'3px solid #183d2c':'3px solid transparent',paddingBottom:'9px'});});
 html+=box(62,480,640,6,'',{background:'#173d2c',transform:`scaleX(${join})`,transformOrigin:'left'});
 html+=txt('跟着声音，重新合在一起。',66,516,30,{color:'#15382c',fontWeight:650,opacity:join});
 return html;
}
function brightSpace(t){return `<div class="fill" style="background:#f4f1e6"></div><div class="grain"></div><div class="fill" style="background:radial-gradient(ellipse at 50% 55%,#fffdf4bb,transparent 65%)"></div>${[0,1,2].map(i=>box(65+i*38,110+i*30,1120-i*76,680-i*60,'',{border:'1px solid #c9c8bd',borderRadius:'50% 50% 0 0',transform:`rotate(${(i-1)*-4}deg)`,boxShadow:'inset 0 20px 40px #d3d0bd33',opacity:.6})).join('')}`;}
function background(t){
 const first=tw(t,A('light'),A('light')+.65),second=tw(t,A('use'),A('use')+.7);
 let html=techBase(t)+`<div class="fill" style="clip-path:circle(${first*160}% at 50% 50%)">${brightSpace(t)}</div><div class="fill" style="clip-path:circle(${second*160}% at 50% 50%);background:#3962e8"><div class="fill" style="background:radial-gradient(ellipse at 25% 0,#8c9fff88,transparent 70%)"></div>${box(780,-270,630,1200,'',{background:'#f7f3de',borderRadius:'50%',transform:'rotate(35deg)'})}</div>`;
 html+=brand('换背景 / 人物继续讲',first>.5?'#213a39':'#eeecff');
 const color=first>.5&&second<.5?'#173c35':'#fffaf0';
 html+=txt(t<A('switch')?'背景不喜欢？':'换一个。',52,126,100,{color,letterSpacing:'-4px',zIndex:10});
 html+=txt(second>.5?'明亮 · 自由切换':first>.5?'纸面 · 更轻盈':'光影 · 更有纵深',57,251,22,{color,fontWeight:500,letterSpacing:'3px'});
 html+=actor(t,355,650,{filter:second>.5?'drop-shadow(8px 1px #e1e0d0)':'drop-shadow(1px 4px 22px #0002)'});
 html+=box(70,531,240,61,`<div style="display:flex;gap:10px;align-items:center">${['#151a42','#ece5cf','#3962e8'].map((s,i)=>`<span style="display:block;width:36px;height:36px;border-radius:50%;background:${s};border:${i===(second>.5?2:first>.5?1:0)?'3px solid #ed9569':'2px solid #ffffff99'};transform:scale(${i===(second>.5?2:first>.5?1:0)?1.2:1})"></span>`).join('')}<span style="font-size:12px;color:${color};margin-left:9px">背景切换</span></div>`,{zIndex:30});
 if(t>A('use'))html+=box(975,373,240,160,`<div style="font-size:21px;line-height:1.55;font-weight:700;color:#173e3c">人像与内容<br>继续用。<div style="width:45px;height:3px;background:#e96f42;margin-top:16px"></div></div>`,{opacity:tw(t,A('use'),A('use')+.5),zIndex:15});
 return html;
}
function workflow(t){
 let html=techBase(t)+brand('把流程，装进 Skill');
 html+=txt(t<A('package')?'这条片，怎么做？':'下次，从这里继续。',52,119,63,{letterSpacing:'-3px'});
 html+=actor(t,811,565,{filter:'drop-shadow(0 10px 20px #0004)'});
 const p=tw(t,A('codex'),A('codex')+1.5),pack=tw(t,A('package'),A('skill')+.5);
 const steps=['口播文案','我的数字人','四种动效','视频合成'];
 for(let i=0;i<4;i++){let x=68+(i%2)*353,y=260+Math.floor(i/2)*168;let active=tw(t,A('workflow')+i*.45,A('workflow')+.4+i*.45);html+=box(x,y,318,127,`<div style="display:flex;align-items:center;gap:17px"><div style="width:65px;height:65px;border-radius:17px;background:${['#555080','#3b5e67','#76597b','#737f52'][i]};display:grid;place-items:center">${icon(i,'#eeeaff',37)}</div><div><div class="tiny" style="color:#a4a2bd">0${i+1} / ${i===1?'蝉镜':'CODEX'}</div><div style="font-size:25px;font-weight:750;margin-top:11px">${steps[i]}</div></div></div>`,{zIndex:12,padding:'27px 20px',opacity:active,transform:`translateY(${(1-active)*30}px) scale(${1-pack*.07})`},'glass');}
 html+=box(390,307,32,32,'→',{color:'#baaff4',fontSize:'26px',opacity:p});
 html+=box(390,475,32,32,'←',{color:'#baaff4',fontSize:'26px',opacity:p});
 let skillW=650,skillX=78;
 html+=box(skillX,325,skillW,208,`<div style="display:flex;gap:24px;align-items:center;padding:32px 35px"><div style="width:114px;height:130px;border:1px solid #d7cfff55;border-radius:15px;background:linear-gradient(135deg,#9281ba,#403455);display:grid;place-items:center;font-size:67px;font-weight:900">S</div><div><div class="tiny" style="color:#c1b0e5;letter-spacing:4px">MY WORKFLOW</div><div style="font-size:37px;font-weight:850;margin-top:10px">数字人口播 Skill</div><div style="font-size:15px;color:#aaa3ba;margin-top:15px">文案 · 人像 · 风格 · 字幕 · 合成</div></div></div>`,{opacity:pack,transform:`perspective(1200px) rotateY(${(1-pack)*-16}deg) scale(${.75+pack*.25})`,zIndex:30,borderRadius:'24px',background:'linear-gradient(140deg,#363047,#151220)',border:'1px solid #bfb0d764',boxShadow:'0 24px 70px #0008'});
 html+=txt('换主题，就从这里继续改。',81,596,26,{fontWeight:550,color:'#d8c7ee',opacity:tw(t,A('reuse'),A('reuse')+.5)});
 return html;
}
function outro(t){
 let html=paperBase()+brand('数字人口播 Skill','#254639');
 html+=box(-120,405,600,480,'',{background:'#244d3d',transform:'rotate(-12deg)',clipPath:'polygon(0 9%,15% 0,28% 10%,37% 2%,48% 10%,59% 4%,70% 9%,83% 2%,100% 7%,100% 100%,0 100%)'});
 html+=actor(t,-55,710,{filter:'drop-shadow(5px 0 #fff9e2) drop-shadow(-4px 0 #fff9e2) drop-shadow(8px 9px #19403233)'});
 html+=txt('把这套流程，交给你。',635,146,34,{fontWeight:650,color:'#1d4033',letterSpacing:'-1px'});
 html+=txt('关注我',628,238,99,{color:t>A('follow')?'#db663d':'#1b3d30',fontWeight:950,letterSpacing:'-5px',transform:`scale(${pop(t,A('outro'),.8)})`,transformOrigin:'left center'});
 html+=txt('评论区留言',640,368,65,{color:'#1b3d30',fontWeight:900,letterSpacing:'-3px',transform:`translateY(${-Math.sin(clamp((t-A('comment'))/.6)*Math.PI)*13}px)`});
 const cta=tw(t,A('outro')+.4,A('outro')+.9);
 html+=box(642,480,560,91,wordIn('领取这套 Skill',t,A('outro')+.52),{fontSize:'43px',fontWeight:700,padding:'13px 28px',background:'#214936',color:'#fbf3dd',zIndex:30,opacity:cta,transform:`translateY(${(1-cta)*16}px) rotate(-2deg) scale(${1+.025*Math.sin(clamp((t-A('claim'))/.6)*Math.PI)})`,boxShadow:'8px 9px 0 #df9a55'});
 html+=box(1030,94,115,115,svg(`<path d="${star(10,53,44)}" fill="#e9ad4f"/><text x="75" y="77" text-anchor="middle" fill="#173d2f" font-size="19" class="svgtext">四种风格</text><text x="75" y="102" text-anchor="middle" fill="#173d2f" font-size="16" class="svgtext">一套流程</text>`,150,150),{opacity:tw(t,A('outro')+.2,A('outro')+.65),transform:`translateY(${tw(t,A('outro')+.2,A('outro')+.65,12,0)}px) rotate(13deg)`});
 return html;
}
const renderers={intro,sticker,drawing,tech,typography,background,workflow,outro};
let committed=0;
async function render(scene,localTime){
 const token=++committed,t=data.scenes[scene].start+localTime;
 textEntryTime=localTime;textEntryIndex=0;
 const html=renderers[scene](t);
 const tmp=document.createElement('div');tmp.innerHTML=html;
 await Promise.all([...tmp.querySelectorAll('img')].map(im=>im.decode().catch(()=>{})));
 if(token===committed)document.getElementById('stage').replaceChildren(...tmp.childNodes);
}
const ready=Promise.all([fetch('project.json').then(r=>r.json()).then(x=>projectConfig=x),fetch('copy.json').then(r=>r.json()).then(x=>copyMap=x),fetch('timing.json').then(r=>r.json()).then(async x=>{data=x;if(x.introAsset)introData=await fetch(x.introAsset.config).then(r=>r.json())}),fetch('person.json').then(r=>r.json()).then(x=>meta=x),fetch('waveform.json').then(r=>r.json()).then(x=>waveform=x),document.fonts.load('950 125px SC'),document.fonts.load('500 20px SC'),Promise.all(['assets/home-study-v3.png','assets/paper-cream.jpg','assets/paper-mustard.jpg','assets/paper-props-v2.png'].map(src=>{let im=new Image();im.src=src;return im.decode()}))]);
const scene=document.body.dataset.scene;
window.film={width:1280,height:720,ready,frame:async t=>{await ready;await render(scene,t)},get duration(){return scene==='intro'&&introData?introData.duration:(data?.scenes[scene].duration||1)}};


