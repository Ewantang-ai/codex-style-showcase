"""Fully decode a rendered MP4 and save sample frames and factual statistics."""
import argparse, json
from pathlib import Path
import av, numpy as np
from PIL import Image
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--input', required=True)
p.add_argument('--output', required=True)
a=p.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
with av.open(a.input) as media:
    stream=media.streams.video[0]; fps=float(stream.average_rate)
    duration=float(stream.duration*stream.time_base) if stream.duration else float(media.duration/av.time_base)
    targets={round((duration-.1)*fps*k/7) for k in range(8)}
    dimensions=[stream.width,stream.height]; frames=0
    for i,frame in enumerate(media.decode(video=0)):
        if i in targets: Image.fromarray(frame.to_ndarray(format='rgb24')).save(out/f'frame-{i:05d}.png')
        frames+=1
peak=0.; sums=0.; count=0
with av.open(a.input) as media:
    has_audio=bool(media.streams.audio)
    if has_audio:
        for frame in media.decode(audio=0):
            samples=frame.to_ndarray(); z=samples.astype('float64')
            if np.issubdtype(samples.dtype,np.integer): z/=max(abs(np.iinfo(samples.dtype).min),np.iinfo(samples.dtype).max)
            peak=max(peak,float(np.abs(z).max())); sums+=float((z*z).sum()); count+=z.size
report=dict(size=dimensions,fps=fps,frames=frames,duration=frames/fps,hasAudio=has_audio,audioPeak=peak,audioRMS=(sums/count)**.5 if count else 0,allFramesDecoded=True,
    scope='Decoding is not visual or lip-sync approval; inspect motion, captions and speech.')
(out/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
