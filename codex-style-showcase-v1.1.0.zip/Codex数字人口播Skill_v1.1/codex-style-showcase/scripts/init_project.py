"""Create a new editable project; --demo uses no real face, voice or paid service."""
import argparse, json, shutil, wave
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--output', required=True)
p.add_argument('--demo', action='store_true')
a = p.parse_args()
skill = Path(__file__).resolve().parents[1]
out = Path(a.output).resolve()
if out.exists():
    raise SystemExit('Output already exists; choose a new directory to preserve edits.')
shutil.copytree(skill / 'assets' / 'template', out)
if a.demo:
    from PIL import Image, ImageDraw, ImageFont
    person = out / 'assets' / 'person'
    person.mkdir(parents=True)
    im = Image.new('RGBA', (720, 720))
    draw = ImageDraw.Draw(im)
    draw.ellipse((270, 270, 450, 450), fill='#405b65')
    draw.rounded_rectangle((130, 435, 590, 800), radius=95, fill='#405b65')
    font = ImageFont.truetype(str(out / 'assets' / 'NotoSansSC.ttf'), 28)
    draw.text((270, 560), '占位人物', font=font, fill='#fff5de')
    draw.text((270, 608), '静音预演', font=font, fill='#fff5de')
    im.save(person / '0000.webp', lossless=True)
    (out / 'person.json').write_text(json.dumps(dict(width=720, height=720, fps=.01, frames=1, duration=100)), encoding='utf-8')
    lines = [s.strip() for s in (out / '口播文案.txt').read_text(encoding='utf-8').splitlines() if s.strip()]
    durations = [10.96, 9.60, 7.88, 10.44, 7.96, 7.04, 9.84, 5.52]
    if len(lines) != len(durations):
        raise SystemExit('Demo requires the supplied eight-paragraph example script.')
    rows, at = [], 0.0
    for line, length in zip(lines, durations):
        chars = [c for c in line if c.isalnum()]
        step = (length - .4) / len(chars)
        words = [dict(word=c, start=round(at+.2+i*step, 5), end=round(at+.2+(i+1)*step, 5)) for i,c in enumerate(chars)]
        rows.append(dict(start=words[0]['start'], end=words[-1]['end'], text=line, words=words))
        at += length
    (out / 'transcript.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
    with wave.open(str(out / 'assets' / 'voice.wav'), 'wb') as wav:
        wav.setparams((1, 2, 16000, 0, 'NONE', 'not compressed'))
        wav.writeframes(bytes(round(at * 16000) * 2))
    (out / 'waveform.json').write_text(json.dumps([0] * (round(at/.025)+1)), encoding='utf-8')
    (out / 'DEMO_ONLY.txt').write_text('静音预演。占位图不是真人；转写时间由脚本模拟，禁止用于正式口播对齐。', encoding='utf-8')
    project = json.loads((out / 'project.json').read_text(encoding='utf-8'))
    project['presenterName'] = '静音预演'
    (out / 'project.json').write_text(json.dumps(project, ensure_ascii=False, indent=2), encoding='utf-8')
print(out)
