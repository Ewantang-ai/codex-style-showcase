$openFilmBin = Join-Path $PSScriptRoot 'tools\bin'
$env:PATH = "$openFilmBin;$env:PATH"
Set-Location -LiteralPath $PSScriptRoot
& npx.cmd --yes openfilm@0.2.6 @args
exit $LASTEXITCODE
