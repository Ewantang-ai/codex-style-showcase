"""Build a fresh eight-scene template. Existing Studio timelines are not overwritten silently."""
import argparse, json
from pathlib import Path
import av
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--rebuild',action='store_true',help='Explicitly replace generated scene pages and film.html after reviewing edits.')
a=p.parse_args(); R=Path(__file__).resolve().parent
if (R/'film.html').exists() and not a.rebuild: raise SystemExit('film.html exists. Preserve Studio edits; use --rebuild only when replacement is intended.')
d=json.loads((R/'timing.json').read_text(encoding='utf-8'))
keys=[('intro',0),('sticker',d['anchors']['sticker']),('drawing',d['anchors']['draw']),('tech',d['anchors']['tech']),('typography',d['anchors']['type']),('background',d['anchors']['background']),('workflow',d['anchors']['workflow']),('outro',d['anchors']['outro'])]
starts=[round(v*25)/25 for _,v in keys]+[d['duration']]
if any(b<=a for a,b in zip(starts,starts[1:])): raise ValueError('Scene anchors must be strictly chronological. Adapt structure for this script.')
d['scenes']={key:dict(start=starts[i],duration=round(starts[i+1]-starts[i],4)) for i,(key,_) in enumerate(keys)}
intro=json.loads((R/'intro.json').read_text(encoding='utf-8')) if (R/'intro.json').exists() else None
old_intro=d['scenes']['intro']['duration']; delta=round(intro['duration']-old_intro,4) if intro else 0
if intro: d['introAsset']={'config':'intro.json'}
else: d.pop('introAsset',None)
wb=d['scenes']['drawing']; wbfile=R/'assets'/'whiteboard'/'scene-handdraw-whiteboard.mp4'
with av.open(str(wbfile)) as media:
    stream=media.streams.video[0]; wb_duration=float(stream.duration*stream.time_base) if stream.duration else media.duration/av.time_base
speed=wb_duration/wb['duration']
if not .25<=speed<=4: raise ValueError('Whiteboard length unsuitable; render a new segment for this speech.')
clips=[]; scenes={}
for key,row in d['scenes'].items():
    (R/f'{key}.html').write_text(f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><link rel="stylesheet" href="shared.css"></head><body data-scene="{key}"><main id="stage"></main><script src="shared.js"></script></body></html>',encoding='utf-8')
    at=0 if key=='intro' else round(row['start']+delta,4)
    length=intro['duration'] if key=='intro' and intro else row['duration']
    clips.append(f'<iframe id="{key}" src="{key}.html#t=0,{length}" at="{at}"></iframe>'); scenes[key]=dict(start=at,duration=length)
voice=f'<section><audio id="voice" src="assets/voice.wav#t={d["trim"]},{d["trim"]+d["duration"]}" volume="0.88"></audio></section>'
if intro: voice=f'<section><audio id="intro-voice" src="assets/intro-voice.wav#t={intro["trim"]},{intro["trim"]+intro["duration"]}" volume="0.88"></audio><audio id="voice" src="assets/voice.wav#t={d["trim"]+old_intro},{d["trim"]+d["duration"]}" at="{intro["duration"]}" volume="0.88"></audio></section>'
track=f'<section><video id="handdraw" src="assets/whiteboard/scene-handdraw-whiteboard.mp4#t=0,{wb_duration:.6f}" at="{wb["start"]+delta}" speed="{speed:.9f}"></video></section>'
html='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=1280, height=720"></head><body><section>\n'+'\n'.join(clips)+'\n</section>'+track+voice+'</body></html>'
(R/'timing.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
(R/'film.html').write_text(html,encoding='utf-8')
plan=dict(duration=round(d['duration']+delta,4),introReplacement=bool(intro),shift=delta,scenes=scenes,whiteboardSpeed=speed)
(R/'edit-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps(plan))
