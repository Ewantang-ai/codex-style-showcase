"""Read-only environment check. Does not install software or call paid services."""
import argparse, importlib.util, json, shutil, sys
from pathlib import Path
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--project')
a = p.parse_args()
deps = {name: importlib.util.find_spec(module) is not None for name,module in [('numpy','numpy'),('Pillow','PIL'),('av','av'),('opencv-python','cv2'),('imageio-ffmpeg','imageio_ffmpeg')]}
ffmpeg = shutil.which('ffmpeg')
if a.project:
    local = Path(a.project) / 'tools' / 'bin' / ('ffmpeg.exe' if sys.platform=='win32' else 'ffmpeg')
    if local.exists(): ffmpeg = str(local)
report = dict(python=sys.version.split()[0], node=shutil.which('node'), npx=shutil.which('npx.cmd') or shutil.which('npx'), ffmpeg=ffmpeg, dependencies=deps,
    manualChecks=['Browser control availability', 'Own Chanjing login and assets if generating', 'ASR service/model for real speech', 'Image generation service for new artwork'])
print(json.dumps(report, ensure_ascii=False, indent=2))
sys.exit(0 if all(deps.values()) and report['node'] and report['npx'] else 1)
